import './style.css'
import Yotsuba from './R.1776af3109d6df811b37fa224d2a8f.svg'
import YotsubaStaring from '/h19awvyiywn91.svg'

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
  <div>
    <a href="http://www.yotuba.com/" target="_blank">
      <img src="${YotsubaStaring}" class="logo" alt="Yotsuba staring" />
    </a>
    <a href="https://www.reddit.com/r/yotsuba/" target="_blank">
      <img src="${Yotsuba}" class="logo vanilla" alt="Yotsuba" />
    </a>
    <h1>Yotuba.com + Reddit</h1>
    <p>Made with <a href = https://vite.dev/>Vite</a></p>
    <p>This webpage is not related in any way to Yotsuba Sutazio or Kiyohiko Azuma.</p>
  </div>
`


